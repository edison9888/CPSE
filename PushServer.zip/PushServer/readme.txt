1. run php to push test notification.

   php simplepushTest.php

2. new api is needed
   
   need to add a new api to accept ios device id and store it in db
   then use it to push notice.
